//jshint esversion:6

const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const _ = require("lodash")

const homeStartingContent = "Welcome to Your Daily Journal Life moves fast. Every day brings new experiences, challenges, and little victories that shape who we are. Often, we let these moments slip away without pausing to reflect, but your journal is here to change that. This platform is designed as a safe, simple, and inspiring space where you can capture your thoughts, track your progress, and preserve your memories one day at a time.Your Daily Journal is more than just a writing tool—it’s your personal companion. Whether you want to write about your day, record your goals, celebrate achievements, or simply jot down random thoughts, this space encourages you to be open and consistent. Reflection is one of the most powerful habits you can build, and by writing daily, you give yourself the chance to learn from yesterday, live in the present, and plan for tomorrow.We believe journaling isn’t about perfection. It’s about expression. You don’t need to be a professional writer to pour out your feelings here. This journal is private, personal, and tailored for you. Each entry, no matter how long or short, adds value to your journey. Some days, you may write a paragraph; on others, it could be just a sentence. What matters most is the habit of showing up.In today’s busy world, taking a few minutes to pause and write helps you declutter your mind, reduce stress, and increase self-awareness. Looking back, you’ll be able to see your growth, recognize patterns, and gain clarity about where you’re headingSo, take a moment today. Write freely, honestly, and without judgment. Make this journal your safe corner on the web—your personal timeline of thoughts, feelings, and lessons. Each page you fill becomes part of your story.Start journaling today, and let your words become the foundation of your growth, peace, and inspiration.";
const aboutContent = "Welcome to Your Daily Journal—a simple but powerful space created to help you capture your thoughts, track your growth, and celebrate your journey.We live in a world that moves fast. Every day brings challenges, victories, and lessons. Yet, many of those meaningful moments fade away because we don’t pause to reflect. That’s why this journal exists—to give you a calm corner of the web where you can slow down, breathe, and write.Our mission is simple: to make journaling easy, accessible, and meaningful for everyone. You don’t need to be a writer to use this space. You don’t need the “perfect words.” All you need is the willingness to show up, write honestly, and allow yourself to grow through self-reflection.Why journaling? Because it works. Studies show that daily writing can:Reduce stress and anxiety.Improve creativity and problem-solving skills.Build emotional resilience.Strengthen memory and focus.Help you discover clarity and direction in life.We believe your thoughts matter. They deserve to be written down, remembered, and revisited. Your Daily Journal was built with simplicity in mind—no distractions, no unnecessary complexity—just you, your words, and a clean space to record your journey.But this isn’t just about writing. It’s about growth. Each entry you make adds to a collection of stories that reflect who you are, where you’ve been, and where you’re heading. Over time, you’ll see your progress, notice patterns, and celebrate how far you’ve come.This website was created with passion for people who want to live with intention. It’s more than a tool; it’s a companion. Whether you write daily, weekly, or whenever you feel inspired, your journal will always be here for you.We invite you to make this space yours. Write with freedom. Reflect with honesty. And let your story unfold—one entry at a time.Thank you for being part of this journey with us";
const contactContent = "We’re always happy to hear from you! Whether you have a question, suggestion, or just want to share your thoughts, the Your Daily Journal team is here to listen. This space was built for people like you, and your feedback helps us grow, improve, and serve you better.We understand that journaling is a personal journey, and sometimes you may want guidance, support, or technical help while using this platform. That’s why we’ve made it easy to reach out. No matter the reason, big or small, we encourage you to get in touch—we’ll respond with care and attention.Here are a few common reasons people contact us:Questions about how to use the journal features.Reporting a bug or technical issue.Sharing ideas for improvements or new features.General encouragement or testimonials about your journaling journey.Collaboration opportunities or partnership inquiries. We're sorry our contact form is still under development";
const posts = [];


const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));


// home page
app.get('/', function(req, res){

    res.render('home', { homeStartingContent: homeStartingContent, posts: posts});
})


// about page
app.get('/about', function(req, res){

    res.render('about', { aboutContent: aboutContent});
})


// contact page
app.get('/contact', function(req, res){

    res.render('contact', { contactContent: contactContent});
})



//faqs
app.get('/faq', function(req, res){
    res.render('faq');
})

// compose page
app.get('/compose', function(req, res){

    res.render('compose');
})


// post :postTitle
app.get('/posts/:postTitle', function(req, res){

    let requestTitle = _.lowerCase(req.params.postTitle)

    console.log('requestTitle', requestTitle);

    posts.forEach(function(post){
        if(_.lowerCase(post.postTitle) === requestTitle){

            res.render('post', {post: post});
        }
    })

});


app.post('/compose', function(req, res){

    let postTitle = req.body.postTitle
    let postBody = req.body.postBody

    let postObj = {
        postTitle: postTitle,
        postBody: postBody
    }

    posts.push(postObj)

    res.redirect('/')

})







//   // Get references
//   const form = document.getElementById("journalForm");
//   const titleInput = document.getElementById("postTitle");
//   const bodyInput = document.getElementById("postBody");
//   const savedPostsDiv = document.getElementById("savedPosts");

//   // Load existing posts from localStorage
//   function loadPosts() {
//     let posts = JSON.parse(localStorage.getItem("journalPosts")) || [];
//     savedPostsDiv.innerHTML = "";

//     posts.forEach((post, index) => {
//       savedPostsDiv.innerHTML += `
//         <div class="card mt-2 p-2">
//           <h3>${post.title}</h3>
//           <p>${post.body}</p>
//         </div>
//       `;
//     });
//   }

//   // Save post to localStorage
//   form.addEventListener("submit", function(e) {
//     e.preventDefault();

//     let title = titleInput.value.trim();
//     let body = bodyInput.value.trim();

//     if (title && body) {
//       let posts = JSON.parse(localStorage.getItem("journalPosts")) || [];
//       posts.push({ title, body });
//       localStorage.setItem("journalPosts", JSON.stringify(posts));

//       // Clear inputs
//       titleInput.value = "";
//       bodyInput.value = "";

//       // Reload posts
//       loadPosts();
//     }
//   });

//   // Load posts on page load
//   window.onload = loadPosts;












































 
//   // ---------------- GREETING ----------------
//   function getGreeting() {
//     let hour = new Date().getHours();
//     if (hour >= 5 && hour < 12) {
//       return "Good Morning";
//     } else if (hour >= 12 && hour < 17) {
//       return "Good Afternoon";
//     } else if (hour >= 17 && hour < 21) {
//       return "Good Evening";
//     } else {
//       return "Good Night";
//     }
//   }

 
//   // ---------------- POSTS ----------------
//   function loadPosts() {
//     let posts = JSON.parse(localStorage.getItem("journalPosts")) || [];
//     savedPostsDiv.innerHTML = "";

//     posts.forEach((post, index) => {
//       savedPostsDiv.innerHTML += `
//         <div class="card mt-2 p-2">
//           <h3>${post.title}</h3>
//           <p>${post.body}</p>
//           <button onclick="deletePost(${index})" class="btn btn-danger btn-sm">Delete</button>
//         </div>
//       `;
//     });
//   }

 





















app.listen(5000, function() {
  console.log("Server started on port 5000");
});
